/**
 * MyAnimation
 * @constructor
 */

function MyAnimation(id) {
  this.id = id;
};

MyAnimation.prototype.update = function(currTime) {};
MyAnimation.prototype.getPosition = function() {};
MyAnimation.prototype.getAngle = function() {};

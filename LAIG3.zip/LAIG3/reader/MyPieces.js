/**
 * MyPieces
 * @constructor
 */

function MyPieces(scene, id, line, column, player, nrindicators, indicators) {

  this.id = id;
  this.line = line;
  this.column =  column;
  this.player = player;
  this.nrindicators = nrindicators;
};
